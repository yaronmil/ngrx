import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import * as questionActions from './store/questions-actions';
import * as  questionselectors from './store/question-selectors';
import { State } from './store/questions-reducer';
import { Question } from './question.model';
import { tap } from 'rxjs/operators';



@Component({
  selector: 'app-questions-layout',
  templateUrl: './questions-layout.component.html',
  styleUrls: ['./questions-layout.component.css']
})
export class QuestionsLayoutComponent implements OnInit {

  questions: Question[] = [];
  index: number = -1;
  maxQuestions: number = 0;
  selectedText: string = '';

  constructor(private store: Store<State>) {
    this.store.dispatch(new questionActions.SetMock())
    this.store.select(questionselectors.selectQuestionIndex).pipe(tap(d => { this.index = d }
    )).subscribe();
    this.store.select(questionselectors.selectMaxQuestionsx).pipe(tap(d => { this.maxQuestions = d }
    )).subscribe();
    this.store.dispatch(new questionActions.LoadRequestAction())
    this.store.select(questionselectors.selectAllMyFeatureItems).pipe(tap(d => { this.questions = d }
    )).subscribe();

  }
  answerSelected(selectedText: string) {
    this.selectedText = selectedText

  }
  pageChane(event: { page: number }) {
    if (event.page > this.index && this.index < this.maxQuestions) {
      this.store.dispatch(new questionActions.LoadRequestAction())
    }
    else {
      this.store.dispatch(new questionActions.UpdateSelectedIndex(event.page))
    }


  }
  ngOnInit(): void {

  }

}
