export interface ServerQuestion {
  id: string
  difficulty?: string;
  question: string;
  correct_answer: string;
  incorrect_answers: string[]
  allAnswersRandomly?: string[];
}

export interface Question {
  id: number
  question: string;
  answers: { answerText: string, isCorrect: boolean }[];
}
