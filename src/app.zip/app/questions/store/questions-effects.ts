import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { EMPTY } from 'rxjs';
import { map, mergeMap, catchError } from 'rxjs/operators';
import { AppHttpService } from 'src/app/shared/app-http.service';
import * as questionActions from './questions-actions';

@Injectable()
export class QuestionsEffects {

  loadQuestions$ = createEffect(() => this.actions$.pipe(
    ofType(questionActions.QuestionActionTypes.LOAD_REQUEST),
    mergeMap(() => this.appHttp.getQuestion()
      .pipe(
        map(question => new questionActions.LoadSuccessAction(question)),
        catchError(() => EMPTY)
      ))
  )
  );

  constructor(
    private actions$: Actions,
    private appHttp: AppHttpService
  ) { }
}
