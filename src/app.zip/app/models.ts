export interface MyModel {
  id: string;
}
